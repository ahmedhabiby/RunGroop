package com.webApp.App2025;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App2025ApplicationTests {

	@Test
	void contextLoads() {
	}

}
