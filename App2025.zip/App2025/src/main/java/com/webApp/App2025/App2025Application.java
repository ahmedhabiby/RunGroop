package com.webApp.App2025;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class App2025Application {

	public static void main(String[] args) {
		SpringApplication.run(App2025Application.class, args);
	}

}
